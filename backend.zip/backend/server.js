const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);
require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const mqtt = require('mqtt');
const Telemetry = require('./models/Telemetry');

const app = express();
const server = http.createServer(app);

// Khởi tạo Socket.io để đẩy dữ liệu real-time xuống Web Frontend
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// ========================================================
// 1. KẾT NỐI CƠ SỞ DỮ LIỆU MONGODB ATLAS
// ========================================================
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/iot_climate_db';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('✅ [MongoDB Atlas] Kết nối Database thành công!'))
  .catch(err => console.error('❌ [MongoDB Atlas] Lỗi kết nối:', err.message));

// ========================================================
// 2. KẾT NỐI HIVEMQ CLOUD (MQTT OVER SSL - PORT 8883)
// ========================================================
// Mặc định HiveMQ Cloud dùng giao thức mqtts:// và port 8883
const MQTT_BROKER = process.env.MQTT_BROKER_URL || 'mqtts://your-hivemq-instance.hivemq.cloud:8883';
const TOPIC_TELEMETRY = process.env.MQTT_TOPIC_TELEMETRY || 'hcmute/iot/climate/telemetry';
const TOPIC_STATUS = process.env.MQTT_TOPIC_STATUS || 'hcmute/iot/climate/status';
const TOPIC_CONTROL = process.env.MQTT_TOPIC_CONTROL || 'hcmute/iot/climate/control';

const mqttOptions = {
  clientId: 'nodejs_backend_' + Math.random().toString(16).substring(2, 8),
  clean: true,
  reconnectPeriod: 5000,
  rejectUnauthorized: true // Bắt buộc mã hóa SSL cho HiveMQ Cloud
};

if (process.env.MQTT_USERNAME) mqttOptions.username = process.env.MQTT_USERNAME;
if (process.env.MQTT_PASSWORD) mqttOptions.password = process.env.MQTT_PASSWORD;

const mqttClient = mqtt.connect(MQTT_BROKER, mqttOptions);

mqttClient.on('connect', () => {
  console.log(`✅ [HiveMQ Cloud] Đã kết nối thành công tới ${MQTT_BROKER}`);
  mqttClient.subscribe([TOPIC_TELEMETRY, TOPIC_STATUS], (err) => {
    if (!err) {
      console.log(`📡 [MQTT Subscribe] Đang lắng nghe topic: ${TOPIC_TELEMETRY} & ${TOPIC_STATUS}`);
    }
  });
});

mqttClient.on('error', (err) => {
  console.error('❌ [MQTT Error]:', err.message);
});

// Xử lý gói tin nhận từ MQTT -> Lưu MongoDB -> Đẩy Real-time qua Socket.io
mqttClient.on('message', async (topic, message) => {
  if (topic === TOPIC_TELEMETRY) {
    try {
      const payload = JSON.parse(message.toString());
      
      const ind = payload.indoor || payload.in || {};
      const out = payload.outdoor || payload.out || {};

      const record = new Telemetry({
        deviceId: payload.device_id || 'ESP32_CLIMATE_NODE',
        timestamp: payload.timestamp ? new Date(payload.timestamp) : new Date(),
        indoor: {
          temperature: Number(ind.temperature || payload.temperature || 0),
          humidity: Number(ind.humidity || payload.humidity || 0),
          heatIndex: Number(ind.heat_index || calculateHeatIndex(ind.temperature, ind.humidity)),
          lux: Math.round(Number(ind.lux || 0)),
          motion: (ind.motion === 1 || ind.motion === true) ? 1 : 0
        },
        outdoor: {
          temperature: Number(out.temperature || 0),
          humidity: Number(out.humidity || 0),
          heatIndex: Number(out.heat_index || calculateHeatIndex(out.temperature, out.humidity)),
          lux: Math.round(Number(out.lux || 0))
        },
        actuators: {
          fanState: payload.fan_state || 'OFF',
          fanPwm: Number(payload.fan_pwm || 0),
          ledState: payload.led_state || 'OFF',
          ledPwm: Number(payload.led_pwm || 0)
        },
        mode: (payload.mode || 'AUTO').toUpperCase()
      });

      await record.save();
      console.log(`💾 [MongoDB Saved] | Trong: ${record.indoor.temperature}°C | Ngoài: ${record.outdoor.temperature}°C`);

      // TỰ ĐỘNG ĐẨY DỮ LIỆU TỚI FRONTEND QUA SOCKET.IO
      io.emit('telemetry_update', record);

    } catch (err) {
      console.error('❌ [Lỗi xử lý tin nhắn MQTT]:', err.message);
    }
  }
});

function calculateHeatIndex(T, RH) {
  if (!T || !RH) return 0;
  return Number((T + 0.33 * (RH / 100 * 6.105 * Math.exp(17.27 * T / (237.7 + T))) - 4.0).toFixed(1));
}

// ========================================================
// 3. SOCKET.IO CONNECTION HANDLING
// ========================================================
io.on('connection', (socket) => {
  console.log(`🔌 [Socket.io] Web Client đã kết nối: ${socket.id}`);
  socket.on('disconnect', () => {
    console.log(`❌ [Socket.io] Web Client ngắt kết nối: ${socket.id}`);
  });
});

// ========================================================
// 4. REST API CHO FRONTEND
// ========================================================
app.get('/api/v1/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    serverTime: new Date(),
    mongoConnected: mongoose.connection.readyState === 1,
    mqttConnected: mqttClient.connected
  });
});

app.get('/api/v1/telemetry/latest', async (req, res) => {
  try {
    const latestData = await Telemetry.findOne().sort({ timestamp: -1 });
    if (!latestData) return res.status(404).json({ success: false, message: 'Chưa có dữ liệu.' });
    res.json({ success: true, data: latestData });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/v1/telemetry/history', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 60;
    const history = await Telemetry.find().sort({ timestamp: -1 }).limit(limit);
    res.json({ success: true, count: history.length, data: history.reverse() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/v1/control', (req, res) => {
  const { actuator, state, pwm, mode } = req.body;
  const cmdPayload = {};
  if (actuator) cmdPayload.actuator = actuator;
  if (state) cmdPayload.state = state;
  if (pwm !== undefined) cmdPayload.pwm = Number(pwm);
  if (mode) cmdPayload.mode = mode;

  if (mqttClient && mqttClient.connected) {
    mqttClient.publish(TOPIC_CONTROL, JSON.stringify(cmdPayload), { qos: 1 }, (err) => {
      if (err) return res.status(500).json({ success: false, error: 'Lỗi gửi MQTT' });
      res.json({ success: true, message: 'Đã gửi lệnh xuống ESP32!', payload: cmdPayload });
    });
  } else {
    res.status(503).json({ success: false, error: 'MQTT Broker chưa kết nối.' });
  }
});

// Khởi chạy HTTP Server cùng Socket.io
server.listen(PORT, () => {
  console.log(`🚀 [Node.js Server] Đang chạy tại http://localhost:${PORT}`);
});